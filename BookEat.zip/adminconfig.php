<?php

$conn2 = mysqli_connect('localhost','root','','adminlog') or die('connection failed');

session_start();

?>